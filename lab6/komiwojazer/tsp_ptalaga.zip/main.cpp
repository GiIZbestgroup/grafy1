#include <vector> 
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <string>
#include <fstream>
#include <algorithm>
#include <ctime>

#define cityquantity 100


void clrScr() { system("clear"); } 

std::vector <std::vector<double>> fromfile(int& numberofNodes,int& numberofEdges)
{
        std::ifstream file("adjMat.txt");
        int x_size,y_size;
        file >> x_size;
        file >> y_size;
        x_size = static_cast<int>(x_size);

        double tmp;



        if(x_size != 0)
        {
            std::vector<std::vector<double>> connectionArray1(x_size,std::vector<double> (x_size));
            for(int i=0; i<x_size; i++)
            {
                for(int j=0; j<x_size; j++)
                {
                    file >> tmp;
                    if (tmp)
                        numberofEdges++;
                    connectionArray1[i][j] = tmp;
                }
            }
            numberofNodes = x_size;
            return connectionArray1;
        }
        else
        {
            std::vector <std::vector<double>> k;
            std::cout<<"Niestety nie"<<std::endl;
            return k;
        }
}

std::vector <std::vector<int>> pointsfromfile()
{
        std::ifstream file("komiwojazer2.dat");

        int tmp;

            std::vector<std::vector<int>> vektortab(cityquantity,std::vector<int> (3));
            for(int i=0; i<cityquantity; i++)
            {
                for(int j=0; j<3; j++)
                {
                    file >> tmp;
                    vektortab[i][j] = tmp;
                }
            }
            return vektortab;

}

void tofile(double path, std::vector <int> numvector,int counter)
{
        std::ofstream file("numvector.txt");
        file <<"Najkrótsza ścieżka: "<<path<<"\n";

            for(unsigned j=0; j<numvector.size(); j++)
            {
                file <<numvector[j]<<" ";
            }
        file <<"\n"<<counter;

}

void pointstofile(std::vector <int> numvector,std::vector <std::vector<int>> points)
{
        std::ofstream file("resultpoints.txt");
            for(int i=0; i<cityquantity; i++)
            {
                file << points[numvector[i]][0] <<" "<<points[numvector[i]][1]<<" "<<points[numvector[i]][2];  
                file <<"\n";
            }

}

//Zwraca długość
double getLength(std::vector <int> numvector, std::vector<std::vector<double>> array)
{
	double length = 0;

	for(unsigned i = 0; i < (numvector.size()-1); i++)
	{
		length += array[numvector[i]][numvector[i+1]];
	}

	length += array[numvector[numvector.size()-1]][numvector[0]];

	return length;
}

int randomna(int i)
{
	srand(time(0));
	return rand()%i;
}

//Operacja 2-opt
void swapTwo(std::vector<int> &path)
{
  int rand1 = rand()%(path.size());
  int rand2 = rand()%(path.size());

  while(!((rand1 != rand2)&&(rand1<rand2)))
  {
    rand1 = rand()%(path.size());
    rand2 = rand()%(path.size());
  }

  std::vector<int>::iterator nth1 = path.begin() + rand1;
  std::vector<int>::iterator nth2 = path.begin() + rand2;

  std::reverse(nth1,nth2);

}


//3-opt
void swapThree(std::vector<int> &path)
{
  int rand1 = rand()%(path.size());
  int rand2 = rand()%(path.size());
  int rand3 = rand()%(path.size());

  while(!((rand1 != rand2)&&((rand2 != rand3))&&(rand1<rand2)&&(rand2<rand3)))
  {
    rand1 = rand()%(path.size());
    rand2 = rand()%(path.size());
    rand3 = rand()%(path.size());
  }

  std::vector<int>::iterator nth2 = path.begin() + rand2;
  std::vector<int>::iterator nth3 = path.begin() + rand3;

  std::reverse(nth2,nth3);


  std::vector<int>::iterator nth1 = path.begin() + rand1;
  nth3 = path.begin() + rand3;

  std::reverse(nth1,nth3);

}


//Funkcja zwracająca prawdopodobieństwo
double probability(float energy,float energy_new,double temperature,double temperatureold)
{
  return std::min(1.0,exp((energy-energy_new))*1.0/(temperatureold-temperature));
}

//Paramter określający temperaturę początkową
double startingtemperature = 1.5/sqrt(cityquantity);

int alpha = 10;

int temperaturelength = alpha*cityquantity;

//Parametr określający limit temperatury
double temperaturelimit = 10e-3;

//FUnkcja determinująca jak z każdą iteracją będzie maleć temperatura

double changeTemperature(double oldtemperature,int cmod)
{
  return oldtemperature*0.995; 
}



int main()
{

	std::vector<std::vector<double> > connectionArray(cityquantity,std::vector<double>(cityquantity));
	std::vector<std::vector<double> > tmpCarray(cityquantity,std::vector<double>(cityquantity));
  std::vector<std::vector<int> > points(cityquantity,std::vector<int>(3));

	int numberofNodes, numberofEdges;

   	connectionArray = fromfile(numberofNodes,numberofEdges);
    points = pointsfromfile();

    tmpCarray = connectionArray;

    double temperature = startingtemperature;
    double SPlenght;

    std::vector<int> vertices;
    std::vector<int> vertices2;
    std::vector<int> bestvertices;
    std::vector<int> bestverticesiniteration;

    for(int i = 0; i<cityquantity; i++)
    {
    	vertices.push_back(i);
    	vertices2.push_back(i);
    	bestvertices.push_back(i);
      bestverticesiniteration.push_back(i);
    }
   

    SPlenght = getLength(vertices,connectionArray);

    //std::cout<<"Początkowa długość"<<SPlenght;

    SPlenght = getLength(vertices,connectionArray);

    tofile(SPlenght,vertices,0);

    pointstofile(vertices,points);

    srand(time(0));

    double probabilityofdoing;

    bestvertices = vertices;

    int counter = 0;
    
    //Ta zmienna będzie przechowywać temperaturę z poprzedniej iteracji

    double temperatureold = changeTemperature(temperature,1);

    long int cmod = 0;

    int timesnotchanges = 0;

    while(true)
    {

 
    timesnotchanges = 0;
   
    if((!(counter%5000))||timesnotchanges==1000)
    {
      std::random_shuffle(bestverticesiniteration.begin(),bestverticesiniteration.end(),randomna);
    }

    counter++;

    vertices = bestverticesiniteration;

    //Licznik iteracji wewnętrznej pętli
    cmod = 0;

    //Pętla algorytmu Metropolisa
    while(temperature>temperaturelimit)
    {

      vertices2 = vertices;

      cmod++;

      swapTwo(vertices2);

      probabilityofdoing = probability(getLength(vertices,connectionArray),getLength(vertices2,connectionArray),temperature,temperatureold);

   	
    //	std::cout<<"Próba: "<<cmod<<std::endl;
    //	std::cout<<"Energia stara: "<<getLength(vertices,connectionArray)<<std::endl;
    //	std::cout<<"Energia nowa: "<<getLength(vertices2,connectionArray)<<std::endl;


    	if(probabilityofdoing>rand()/(RAND_MAX+1.0))
    	{
    		vertices = vertices2;
    	}
      else
      {
        timesnotchanges++;
      }

  
    	if(getLength(bestvertices,connectionArray)>getLength(vertices,connectionArray))
    	{
    		bestvertices = vertices;
    		SPlenght = getLength(bestvertices,connectionArray);
    		tofile(SPlenght,bestvertices,counter);
        pointstofile(bestvertices,points);
    	}

      if(getLength(bestverticesiniteration,connectionArray)>getLength(vertices,connectionArray))
      {
        bestverticesiniteration = vertices;
      }

    //	std::cout<<"Najlepsza długość: "<<SPlenght<<std::endl<<"Temperatura: "<<temperature<<std::endl<<"Prawdopodobieństwo: "<<probabilityofdoing<<std::endl;

    //	clrScr();

    temperatureold = temperature;

     // if(!cmod%temperaturelength)
      temperature = changeTemperature(temperature,cmod);

    }

   
    temperature = startingtemperature;


	}


   	return 0;
}